<?php

/**
 * This file holds all of the content for the contextual help screens
 * @package Cosn
 */
class Cosn_Contextual_Help {

	/**
	 * @var WP_Screen
	 */
	public $screen;

	/**
	 * @var string
	 */
	public $screen_name;

	/**
	 * @param string $screen_name
	 */
	function __construct( $screen_name ) {
		$this->screen_name = $screen_name;
	}

	/**
	 * Load the contextual help
	 */
	public function load() {
		$this->screen = get_current_screen();

		if ( method_exists( $this, "load_{$this->screen_name}_help" ) ) {
			call_user_func( array( $this, "load_{$this->screen_name}_help" ) );
		}

		$this->load_help_sidebar();
	}

	/**
	 * Load the help sidebar
	 */
	private function load_help_sidebar() {

		$this->screen->set_help_sidebar(
			'<p><strong>' . __( 'For more information:', 'cosn' ) . '</strong></p>' .
			'<p><a href="https://wordpress.org/plugins/cosn">' . __( 'About Plugin', 'cosn' ) . '</a></p>' .
			'<p><a href="https://wordpress.org/plugins/cosn/faq">' . __( 'FAQ', 'cosn' ) . '</a></p>' .
			'<p><a href="https://wordpress.org/support/plugin/cosn">' . __( 'Support Forum', 'cosn' ) . '</a></p>' .
			'<p><a href="https://sheabunge.com/plugins/cosn">' . __( 'Plugin Website', 'cosn' ) . '</a></p>'
		);
	}

	/**
	 * Reusable introduction text
	 * @return string
	 */
	private function get_intro_text() {
		return __( 'Snippets are similar to plugins - they both extend and expand the functionality of WordPress. Snippets are more light-weight, just a few lines of code, and do not put as much load on your server.', 'cosn' );
	}

	/**
	 * Register and handle the help tabs for the manage snippets admin page
	 */
	private function load_manage_help() {

		$this->screen->add_help_tab( array(
			'id'      => 'overview',
			'title'   => __( 'Overview', 'cosn' ),
			'content' => '<p>' . $this->get_intro_text() .
			             __( ' Here you can manage your existing snippets and perform tasks on them such as activating, deactivating, deleting and exporting.', 'cosn' ) . '</p>',
		) );

		$this->screen->add_help_tab( array(
			'id'      => 'safe-mode',
			'title'   => __( 'Safe Mode', 'cosn' ),
			'content' =>
				'<p>' . __( 'Be sure to check your snippets for errors before you activate them, as a faulty snippet could bring your whole blog down. If your site starts doing strange things, deactivate all your snippets and activate them one at a time.', 'cosn' ) . '</p>' .
				'<p>' . __( "If something goes wrong with a snippet and you can't use WordPress, you can cause all snippets to stop executing by adding <code>define('COSN_SAFE_MODE', true);</code> to your <code>wp-config.php</code> file. After you have deactivated the offending snippet, you can turn off safe mode by removing this line or replacing <strong>true</strong> with <strong>false</strong>.", 'cosn' ) . '</p>',
		) );
	}

	/**
	 * Register and handle the help tabs for the single snippet admin page
	 */
	private function load_edit_help() {

		$this->screen->add_help_tab( array(
			'id'      => 'overview',
			'title'   => __( 'Overview', 'cosn' ),
			'content' => '<p>' . $this->get_intro_text() . __( ' Here you can add a new snippet, or edit an existing one.', 'cosn' ) . '</p>',
		) );

		$snippet_host_links = array(
			__( 'WP Function Me', 'cosn' ) => __( 'https://www.wpfunction.me', 'cosn' ),
			__( 'CSS-Tricks', 'cosn' ) => __( 'https://css-tricks.com/snippets/wordpress/', 'cosn' ),
			__( 'WordPress Stack Exchange', 'cosn' ) => __( 'https://wordpress.stackexchange.com/', 'cosn' ),
			__( 'WP Beginner', 'cosn' ) => __( 'https://www.wpbeginner.com/category/wp-tutorials/', 'cosn' ),
			__( 'GenerateWP', 'cosn' ) => __( 'https://generatewp.com', 'cosn' ),
		);

		$snippet_host_list = '';
		foreach ( $snippet_host_links as $title => $link ) {
			$snippet_host_list .= sprintf( '<li><a href="%s">%s</a></li>', esc_url( $link ), esc_html( $title ) );
		}

		$this->screen->add_help_tab( array(
			'id'      => 'finding',
			'title'   => __( 'Finding Snippets', 'cosn' ),
			'content' =>
				'<p>' . __( 'Here are some links to websites which host a large number of snippets that you can add to your site:', 'cosn' ) .
				'<ul>' . $snippet_host_list . '</ul>' .
				__( 'More places to find snippets, as well as a selection of example snippets, can be found in the <a href="https://github.com/sallecta/cosn/wiki/Finding-snippets">plugin documentation</a>.', 'cosn' ) . '</p>',
		) );

		$this->screen->add_help_tab( array(
			'id'      => 'adding',
			'title'   => __( 'Adding Snippets', 'cosn' ),
			'content' =>
				'<p>' . __( 'You need to fill out the name and code fields for your snippet to be added. While the description field will add more information about how your snippet works, what is does and where you found it, it is completely optional.', 'cosn' ) . '</p>' .
				'<p>' . __( 'Please be sure to check that your snippet is valid PHP code and will not produce errors before adding it through this page. While doing so will not become active straight away, it will help to minimise the chance of a faulty snippet becoming active on your site.', 'cosn' ) . '</p>',
		) );
	}

	/**
	 * Register and handle the help tabs for the import snippets admin page
	 */
	private function load_import_help() {
		$manage_url = cosn()->get_menu_url( 'manage' );

		$this->screen->add_help_tab( array(
			'id'      => 'overview',
			'title'   => __( 'Overview', 'cosn' ),
			'content' => '<p>' . $this->get_intro_text() .
			             __( ' Here you can load snippets from a code snippets export file into the database alongside existing snippets.', 'cosn' ) . '</p>',
		) );

		$this->screen->add_help_tab( array(
			'id'      => 'import',
			'title'   => __( 'Importing', 'cosn' ),
			'content' =>
				'<p>' . __( 'You can load your snippets from a code snippets export file using this page.', 'cosn' ) .
				/* translators: %s: URL to Snippets admin menu */
				sprintf( __( 'Imported snippets will be added to the database along with your existing snippets. Regardless of whether the snippets were active on the previous site, imported snippets are always inactive until activated using the <a href="%s">Manage Snippets</a> page.', 'cosn' ), $manage_url ) . '</p>',
		) );

		$this->screen->add_help_tab( array(
			'id'      => 'export',
			'title'   => __( 'Exporting', 'cosn' ),
			/* translators: %s: URL to Manage Snippets admin menu */
			'content' => '<p>' . sprintf( __( 'You can save your snippets to a code snippets export file using the <a href="%s">Manage Snippets</a> page.', 'cosn' ), $manage_url ) . '</p>',
		) );
	}
}
