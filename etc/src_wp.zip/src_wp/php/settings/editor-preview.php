<?php

/**
 * This file handles the editor preview setting
 *
 * @since 2.0
 * @package Cosn
 */

/**
 * Load the CSS and JavaScript for the editor preview field
 */
function cosn_editor_settings_preview_assets() {
	$plugin = cosn();

	// Enqueue scripts for the editor preview
	cosn_enqueue_editor();

	// Enqueue all editor themes
	$themes = cosn_get_available_themes();

	foreach ( $themes as $theme ) {
		if ( 'default' !== $theme ) {
			wp_enqueue_style(
				'cosn-editor-theme-' . $theme,
				plugins_url( "css/min/editor-themes/$theme.css", $plugin->file ),
				array( 'cosn-editor' ), $plugin->version
			);
		}
	}

	// Enqueue the menu scripts
	wp_enqueue_script(
		'cosn-settings-menu',
		plugins_url( 'js/min/settings.js', $plugin->file ),
		array( 'cosn-editor' ), $plugin->version, true
	);

	// Extract the CodeMirror-specific editor settings
	$setting_fields = cosn_get_settings_fields();
	$editor_fields = array();

	foreach ( $setting_fields['editor'] as $name => $field ) {
		if ( empty( $field['codemirror'] ) ) {
			continue;
		}

		$editor_fields[] = array(
			'name' => $name,
			'type' => $field['type'],
			'codemirror' => addslashes( $field['codemirror'] ),
		);
	}

	// Pass the saved options to the external JavaScript file
	$inline_script = 'var cosn_editor_atts = ' . cosn_get_editor_atts( array(), true ) . ';';
	$inline_script .= "\n" . 'var cosn_editor_settings = ' . wp_json_encode( $editor_fields ) . ';';

	wp_add_inline_script( 'cosn-settings-menu', $inline_script, 'before' );
}

/**
 * Render a theme select field
 *
 * @param array $atts
 */
function cosn_codemirror_theme_select_field( $atts ) {

	$saved_value = cosn_get_setting( $atts['section'], $atts['id'] );

	echo '<select name="cosn_settings[editor][theme]">';

	// print a dropdown entry for each theme
	foreach ( cosn_get_available_themes() as $theme ) {

		// skip mobile themes
		if ( 'ambiance-mobile' === $theme ) {
			continue;
		}

		printf(
			'<option value="%s"%s>%s</option>',
			$theme,
			selected( $theme, $saved_value, false ),
			ucwords( str_replace( '-', ' ', $theme ) )
		);
	}

	echo '</select>';
}

/**
 * Render the editor preview setting
 */
function cosn_settings_editor_preview() {
	echo '<div id="cosn_editor_preview"></div>';
}
