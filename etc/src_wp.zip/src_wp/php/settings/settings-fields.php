<?php

/**
 * Retrieve the default setting values
 * @return array
 */
function cosn_get_default_settings() {
	static $defaults;

	if ( isset( $defaults ) ) {
		return $defaults;
	}

	$defaults = array();

	foreach ( cosn_get_settings_fields() as $section_id => $fields ) {
		$defaults[ $section_id ] = array();

		foreach ( $fields as $field_id => $field_atts ) {
			$defaults[ $section_id ][ $field_id ] = $field_atts['default'];
		}
	}

	return $defaults;
}

/**
 * Retrieve the settings fields
 * @return array
 */
function cosn_get_settings_fields() {
	static $fields;

	if ( isset( $fields ) ) {
		return $fields;
	}

	$fields = array();

	$fields['general'] = array(
		'activate_by_default' => array(
			'name'    => __( 'Activate by Default', 'cosn' ),
			'type'    => 'checkbox',
			'label'   => __( "Make the 'Save and Activate' button the default action when saving a snippet.", 'cosn' ),
			'default' => true,
		),

		'snippet_scope_enabled' => array(
			'name'    => __( 'Enable Scope Selector', 'cosn' ),
			'type'    => 'checkbox',
			'label'   => __( 'Enable the scope selector when editing a snippet', 'cosn' ),
			'default' => true,
		),

		'enable_tags' => array(
			'name'    => __( 'Enable Snippet Tags', 'cosn' ),
			'type'    => 'checkbox',
			'label'   => __( 'Show snippet tags on admin pages', 'cosn' ),
			'default' => true,
		),

		'enable_description' => array(
			'name'    => __( 'Enable Snippet Descriptions', 'cosn' ),
			'type'    => 'checkbox',
			'label'   => __( 'Show snippet descriptions on admin pages', 'cosn' ),
			'default' => true,
		),

		'disable_prism' => array(
			'name'    => __( 'Disable Shortcode Syntax Highlighter', 'cosn' ),
			'type'    => 'checkbox',
			'label'   => __( 'Disable the syntax highlighting for the [code_snippet] shortcode on the front-end', 'cosn' ),
			'default' => false,
		),

		'complete_uninstall' => array(
			'name'    => __( 'Complete Uninstall', 'cosn' ),
			'type'    => 'checkbox',
			'label'   => sprintf(
				/* translators: %s: URL for Plugins admin menu */
				__( 'When the plugin is deleted from the <a href="%s">Plugins</a> menu, also delete all snippets and plugin settings.', 'cosn' ),
				self_admin_url( 'plugins.php' )
			),
			'default' => false,
		),
	);

	if ( is_multisite() && ! is_main_site() ) {
		unset( $fields['general']['complete_uninstall'] );
	}

	/* Description Editor settings section */
	$fields['description_editor'] = array(

		'rows' => array(
			'name'    => __( 'Row Height', 'cosn' ),
			'type'    => 'number',
			'label'   => __( 'rows', 'cosn' ),
			'default' => 5,
			'min'     => 0,
		),

		'use_full_mce' => array(
			'name'    => __( 'Use Full Editor', 'cosn' ),
			'type'    => 'checkbox',
			'label'   => __( 'Enable all features of the visual editor', 'cosn' ),
			'default' => false,
		),

		'media_buttons' => array(
			'name'    => __( 'Media Buttons', 'cosn' ),
			'type'    => 'checkbox',
			'label'   => __( 'Enable the add media buttons', 'cosn' ),
			'default' => false,
		),
	);

	/* Code Editor settings section */

	$fields['editor'] = array(
		'theme' => array(
			'name'       => __( 'Theme', 'cosn' ),
			'type'       => 'codemirror_theme_select',
			'default'    => 'default',
			'codemirror' => 'theme',
		),

		'indent_with_tabs' => array(
			'name'       => __( 'Indent With Tabs', 'cosn' ),
			'type'       => 'checkbox',
			'label'      => __( 'Use hard tabs (not spaces) for indentation.', 'cosn' ),
			'default'    => true,
			'codemirror' => 'indentWithTabs',
		),

		'tab_size' => array(
			'name'       => __( 'Tab Size', 'cosn' ),
			'type'       => 'number',
			'desc'       => __( 'The width of a tab character.', 'cosn' ),
			'default'    => 4,
			'codemirror' => 'tabSize',
			'min'        => 0,
		),

		'indent_unit' => array(
			'name'       => __( 'Indent Unit', 'cosn' ),
			'type'       => 'number',
			'desc'       => __( 'How many spaces a block should be indented.', 'cosn' ),
			'default'    => 4,
			'codemirror' => 'indentUnit',
			'min'        => 0,
		),

		'wrap_lines' => array(
			'name'       => __( 'Wrap Lines', 'cosn' ),
			'type'       => 'checkbox',
			'label'      => __( 'Whether the editor should scroll or wrap for long lines.', 'cosn' ),
			'default'    => true,
			'codemirror' => 'lineWrapping',
		),

		'line_numbers' => array(
			'name'       => __( 'Line Numbers', 'cosn' ),
			'type'       => 'checkbox',
			'label'      => __( 'Show line numbers to the left of the editor.', 'cosn' ),
			'default'    => true,
			'codemirror' => 'lineNumbers',
		),

		'auto_close_brackets' => array(
			'name'       => __( 'Auto Close Brackets', 'cosn' ),
			'type'       => 'checkbox',
			'label'      => __( 'Auto-close brackets and quotes when typed.', 'cosn' ),
			'default'    => true,
			'codemirror' => 'autoCloseBrackets',
		),

		'highlight_selection_matches' => array(
			'name'       => __( 'Highlight Selection Matches', 'cosn' ),
			'label'      => __( 'Highlight all instances of a currently selected word.', 'cosn' ),
			'type'       => 'checkbox',
			'default'    => true,
			'codemirror' => 'highlightSelectionMatches',
		),
	);

	$fields = apply_filters( 'cosn_settings_fields', $fields );

	return $fields;
}
