<?php

class Cosn_Shortcode {

	function __construct() {
		add_shortcode( 'code_snippet', array( $this, 'render_shortcode' ) );
		add_action( 'the_posts', array( $this, 'enqueue_assets' ) );
	}

	function enqueue_assets( $posts ) {

		if ( empty( $posts ) || cosn_get_setting( 'general', 'disable_prism' ) ) {
			return $posts;
		}

		$found = false;

		foreach ( $posts as $post ) {

			if ( false !== stripos( $post->post_content, '[code_snippet' ) ) {
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			return $posts;
		}

		$plugin = cosn();

		wp_enqueue_style(
			'cosn-front-end',
			plugins_url( 'css/min/front-end.css', $plugin->file ),
			array(), $plugin->version
		);

		wp_enqueue_script(
			'cosn-front-end',
			plugins_url( 'js/min/front-end.js', $plugin->file ),
			array(), $plugin->version, true
		);

		return $posts;
	}

	function render_shortcode( $atts ) {

		$atts = shortcode_atts(
			array(
				'id'      => 0,
				'network' => false,
			),
			$atts, 'code_snippet'
		);

		$id = intval( $atts['id'] );
		if ( ! $id ) {
			return '';
		}

		$network = $atts['network'] ? true : false;
		$snippet = cosn_get_snippet( $id, $network );

		if ( ! trim( $snippet->code ) ) {
			return '';
		}

		return '<pre><code class="language-php">' . esc_html( $snippet->code ) . '</code></pre>';
	}
}

