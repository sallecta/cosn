<?php

/**
 * This class handles the manage snippets menu
 * @since   2.4.0
 * @package Cosn
 */
class Cosn_Manage_Menu extends Cosn_Admin_Menu {

	/**
	 * Holds the list table class
	 * @var Cosn_List_Table
	 */
	public $list_table;

	/**
	 * Class constructor
	 */
	public function __construct() {

		parent::__construct( 'manage',
			_x( 'All Snippets', 'menu label', 'cosn' ),
			__( 'Snippets', 'cosn' )
		);
	}

	/**
	 * Register action and filter hooks
	 */
	public function run() {
		parent::run();

		if ( cosn()->admin->is_compact_menu() ) {
			add_action( 'admin_menu', array( $this, 'register_compact_menu' ), 2 );
			add_action( 'network_admin_menu', array( $this, 'register_compact_menu' ), 2 );
		}

		add_filter( 'set-screen-option', array( $this, 'save_screen_option' ), 10, 3 );
		add_action( 'wp_ajax_update_code_snippet', array( $this, 'ajax_callback' ) );
	}

	/**
	 * Register the top-level 'Snippets' menu and associated 'Manage' subpage
	 *
	 * @uses add_menu_page() to register a top-level menu
	 * @uses add_submenu_page() to register a sub-menu
	 */
	function register() {

		/* Register the top-level menu */
		add_menu_page(
			__( 'Cosn', 'cosn' ),
			_x( 'Cosn', 'top-level menu label', 'cosn' ),
			cosn()->get_cap(),
			cosn()->get_menu_slug(),
			array( $this, 'render' ),
			'none', // icon is added through css/min/menu-icon.css
			is_network_admin() ? 21 : 67
		);

		/* Register the sub-menu */
		parent::register();
	}

	public function register_compact_menu() {

		if ( ! cosn()->admin->is_compact_menu() ) {
			return;
		}

		$sub = cosn()->get_menu_slug( isset( $_GET['sub'] ) ? $_GET['sub'] : 'snippets' );

		$classmap = array(
			'snippets'             => 'manage',
			'add-snippet'          => 'edit',
			'edit-snippet'         => 'edit',
			'import-cosn' => 'import',
			'snippets-settings'    => 'settings',
		);

		if ( isset( $classmap[ $sub ], cosn()->admin->menus[ $classmap[ $sub ] ] ) ) {
			/** @var Cosn_Admin_Menu $class */
			$class = cosn()->admin->menus[ $classmap[ $sub ] ];
		} else {
			$class = $this;
		}

		/* Add a submenu to the Tools menu */
		$hook = add_submenu_page(
			'tools.php', //parent_slug
			__( 'Cosn', 'cosn' ), //page_title
			_x( 'Cosn', 'tools submenu label', 'cosn' ), //menu_title
			cosn()->get_cap(), //capability
			cosn()->get_menu_slug(),//menu_slug
			array( $class, 'render' ) //callable $function
		);

		add_action( 'load-' . $hook, array( $class, 'load' ) );

	}

	/**
	 * Executed when the admin page is loaded
	 */
	function load() {
		parent::load();

		/* Load the contextual help tabs */
		$contextual_help = new Cosn_Contextual_Help( 'manage' );
		$contextual_help->load();

		/* Initialize the list table class */
		$this->list_table = new Cosn_List_Table();
		$this->list_table->prepare_items();
	}

	/**
	 * Enqueue scripts and stylesheets for the admin page
	 */
	public function enqueue_assets() {
		$plugin = cosn();
		$rtl = is_rtl() ? '-rtl' : '';

		wp_enqueue_style(
			'cosn-manage',
			plugins_url( "css/min/manage{$rtl}.css", $plugin->file ),
			array(), $plugin->version
		);

		wp_enqueue_script(
			'cosn-manage-js',
			plugins_url( 'js/min/manage.js', $plugin->file ),
			array(), $plugin->version, true
		);

		wp_localize_script(
			'cosn-manage-js',
			'cosn_manage_i18n',
			array(
				'activate'         => __( 'Activate', 'cosn' ),
				'deactivate'       => __( 'Deactivate', 'cosn' ),
				'activation_error' => __( 'An error occurred when attempting to activate', 'cosn' ),
			)
		);
	}

	/**
	 * Print the status and error messages
	 */
	protected function print_messages() {

		/* Output a warning if safe mode is active */
		if ( defined( 'COSN_SAFE_MODE' ) && COSN_SAFE_MODE ) {
			echo '<div id="message" class="error fade"><p>';
			_e( '<strong>Warning:</strong> Safe mode is active and snippets will not execute! Remove the <code>COSN_SAFE_MODE</code> constant from <code>wp-config.php</code> to turn off safe mode. <a href="https://github.com/sallecta/cosn/wiki/Safe-Mode" target="_blank">Help</a>', 'cosn' );
			echo '</p></div>';
		}

		echo $this->get_result_message(
			array(
				'executed'          => __( 'Snippet <strong>executed</strong>.', 'cosn' ),
				'activated'         => __( 'Snippet <strong>activated</strong>.', 'cosn' ),
				'activated-multi'   => __( 'Selected snippets <strong>activated</strong>.', 'cosn' ),
				'deactivated'       => __( 'Snippet <strong>deactivated</strong>.', 'cosn' ),
				'deactivated-multi' => __( 'Selected snippets <strong>deactivated</strong>.', 'cosn' ),
				'deleted'           => __( 'Snippet <strong>deleted</strong>.', 'cosn' ),
				'deleted-multi'     => __( 'Selected snippets <strong>deleted</strong>.', 'cosn' ),
				'cloned'            => __( 'Snippet <strong>cloned</strong>.', 'cosn' ),
				'cloned-multi'      => __( 'Selected snippets <strong>cloned</strong>.', 'cosn' ),
			)
		);
	}

	/**
	 * Handles saving the user's snippets per page preference
	 *
	 * @param mixed  $status
	 * @param string $option The screen option name
	 * @param mixed  $value
	 *
	 * @return mixed
	 */
	function save_screen_option( $status, $option, $value ) {
		if ( 'snippets_per_page' === $option ) {
			return $value;
		}

		return $status;
	}

	/**
	 * Handle AJAX requests
	 */
	public function ajax_callback() {
		check_ajax_referer( 'cosn_manage_ajax' );

		if ( ! isset( $_POST['field'], $_POST['snippet'] ) ) {
			wp_send_json_error( array(
				'type'    => 'param_error',
				'message' => 'incomplete request',
			) );
		}

		$snippet_data = json_decode( stripslashes( $_POST['snippet'] ), true );

		$snippet = new Cosn_Snippet( $snippet_data );
		$field = $_POST['field'];

		if ( 'priority' === $field ) {

			if ( ! isset( $snippet_data['priority'] ) || ! is_numeric( $snippet_data['priority'] ) ) {
				wp_send_json_error( array(
					'type'    => 'param_error',
					'message' => 'missing snippet priority data',
				) );
			}

			global $wpdb;

			$wpdb->update(
				cosn()->db->get_table_name( $snippet->network ),
				array( 'priority' => $snippet->priority ),
				array( 'id' => $snippet->id ),
				array( '%d' ),
				array( '%d' )
			);

		} elseif ( 'active' === $field ) {

			if ( ! isset( $snippet_data['active'] ) ) {
				wp_send_json_error( array(
					'type'    => 'param_error',
					'message' => 'missing snippet active data',
				) );
			}

			if ( $snippet->shared_network ) {
				$active_shared_snippets = get_option( 'active_shared_network_snippets', array() );

				if ( in_array( $snippet->id, $active_shared_snippets, true ) !== $snippet->active ) {

					$active_shared_snippets = $snippet->active ?
						array_merge( $active_shared_snippets, array( $snippet->id ) ) :
						array_diff( $active_shared_snippets, array( $snippet->id ) );

					update_option( 'active_shared_network_snippets', $active_shared_snippets );
				}
			} else {

				if ( $snippet->active ) {
					$result = cosn_activate_snippet( $snippet->id, $snippet->network );
					if ( ! $result ) {
						wp_send_json_error( array(
							'type'    => 'action_error',
							'message' => 'error activating snippet',
						) );
					}
				} else {
					cosn_deactivate_snippet( $snippet->id, $snippet->network );
				}
			}
		}

		wp_send_json_success();
	}
}
