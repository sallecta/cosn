<?php

/**
 * HTML code for the Add New/Edit Snippet page
 *
 * @package    Cosn
 * @subpackage Views
 *
 * @var Cosn_Edit_Menu $this
 */

/* Bail if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	return;
}

$snippet = $this->snippet;
$classes = array();

if ( ! $snippet->id ) {
	$classes[] = 'new-snippet';
} elseif ( 'single-use' === $snippet->scope ) {
	$classes[] = 'single-use-snippet';
} else {
	$classes[] = ( $snippet->active ? '' : 'in' ) . 'active-snippet';
}

?>
<div class="wrap">
	<h1><?php

		if ( $snippet->id ) {
			esc_html_e( 'Edit Snippet', 'cosn' );
			printf( ' <a href="%1$s" class="page-title-action add-new-h2">%2$s</a>',
				cosn()->get_menu_url( 'add' ),
				esc_html_x( 'Add New', 'snippet', 'cosn' )
			);
		} else {
			esc_html_e( 'Add New Snippet', 'cosn' );
		}

		$admin = cosn()->admin;

		if ( cosn()->admin->is_compact_menu() ) {

			printf( '<a href="%2$s" class="page-title-action">%1$s</a>',
				esc_html_x( 'Manage', 'snippets', 'cosn' ),
				cosn()->get_menu_url()
			);

			printf( '<a href="%2$s" class="page-title-action">%1$s</a>',
				esc_html_x( 'Import', 'snippets', 'cosn' ),
				cosn()->get_menu_url( 'import' )
			);

			if ( isset( $admin->menus['settings'] ) ) {

				printf( '<a href="%2$s" class="page-title-action">%1$s</a>',
					esc_html_x( 'Settings', 'snippets', 'cosn' ),
					cosn()->get_menu_url( 'settings' )
				);
			}
		}

		?></h1>

	<form method="post" id="snippet-form" action="" style="margin-top: 10px;" class="<?php echo implode( ' ', $classes ); ?>">
		<?php
		/* Output the hidden fields */

		if ( 0 !== $snippet->id ) {
			printf( '<input type="hidden" name="snippet_id" value="%d">', $snippet->id );
		}

		printf( '<input type="hidden" name="snippet_active" value="%d">', $snippet->active );

		do_action( 'cosn/admin/before_title_input', $snippet );
		?>

		<div id="titlediv">
			<div id="titlewrap">
				<label for="title" style="display: none;"><?php _e( 'Name', 'cosn' ); ?></label>
				<input id="title" type="text" autocomplete="off" name="snippet_name" value="<?php echo esc_attr( $snippet->name ); ?>" placeholder="<?php _e( 'Enter title here', 'cosn' ); ?>">
			</div>
		</div>

		<?php do_action( 'cosn/admin/after_title_input', $snippet ); ?>

		<p class="submit-inline"><?php do_action( 'cosn/admin/code_editor_toolbar', $snippet ); ?></p>

		<h2><label for="snippet_code"><?php _e( 'Code', 'cosn' ); ?></label></h2>

		<div class="snippet-editor">
			<textarea id="snippet_code" name="snippet_code" rows="200" spellcheck="false" style="font-family: monospace; width: 100%;"><?php
				echo esc_textarea( $snippet->code );
				?></textarea>

			<div class="snippet-editor-help">

				<div class="editor-help-tooltip cm-s-<?php
				echo esc_attr( cosn_get_setting( 'editor', 'theme' ) ); ?>"><?php
					echo esc_html_x( '?', 'help tooltip', 'cosn' ); ?></div>

				<?php

				$keys = array(
					'Cmd'    => esc_html_x( 'Cmd', 'keyboard key', 'cosn' ),
					'Ctrl'   => esc_html_x( 'Ctrl', 'keyboard key', 'cosn' ),
					'Shift'  => esc_html_x( 'Shift', 'keyboard key', 'cosn' ),
					'Option' => esc_html_x( 'Option', 'keyboard key', 'cosn' ),
					'Alt'    => esc_html_x( 'Alt', 'keyboard key', 'cosn' ),
					'F'      => esc_html_x( 'F', 'keyboard key', 'cosn' ),
					'G'      => esc_html_x( 'G', 'keyboard key', 'cosn' ),
					'R'      => esc_html_x( 'R', 'keyboard key', 'cosn' ),
					'S'      => esc_html_x( 'S', 'keyboard key', 'cosn' ),
				);

				?>

				<div class="editor-help-text">
					<table>
						<tr>
							<td><?php esc_html_e( 'Save changes', 'cosn' ); ?></td>
							<td>
								<kbd class="pc-key"><?php echo $keys['Ctrl']; ?></kbd><kbd class="mac-key"><?php
									echo $keys['Cmd']; ?></kbd>&hyphen;<kbd><?php echo $keys['S']; ?></kbd>
							</td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Begin searching', 'cosn' ); ?></td>
							<td>
								<kbd class="pc-key"><?php echo $keys['Ctrl']; ?></kbd><kbd class="mac-key"><?php
									echo $keys['Cmd']; ?></kbd>&hyphen;<kbd><?php echo $keys['F']; ?></kbd>
							</td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Find next', 'cosn' ); ?></td>
							<td>
								<kbd class="pc-key"><?php echo $keys['Ctrl']; ?></kbd><kbd class="mac-key"><?php echo $keys['Cmd']; ?></kbd>&hyphen;<kbd><?php echo $keys['G']; ?></kbd>
							</td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Find previous', 'cosn' ); ?></td>
							<td>
								<kbd><?php echo $keys['Shift']; ?></kbd>-<kbd class="pc-key"><?php echo $keys['Ctrl']; ?></kbd><kbd class="mac-key"><?php echo $keys['Cmd']; ?></kbd>&hyphen;<kbd><?php echo $keys['G']; ?></kbd>
							</td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Replace', 'cosn' ); ?></td>
							<td>
								<kbd><?php echo $keys['Shift']; ?></kbd>&hyphen;<kbd class="pc-key"><?php echo $keys['Ctrl']; ?></kbd><kbd class="mac-key"><?php echo $keys['Cmd']; ?></kbd>&hyphen;<kbd><?php echo $keys['F']; ?></kbd>
							</td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Replace all', 'cosn' ); ?></td>
							<td>
								<kbd><?php echo $keys['Shift']; ?></kbd>&hyphen;<kbd class="pc-key"><?php echo $keys['Ctrl']; ?></kbd><kbd class="mac-key"><?php echo $keys['Cmd']; ?></kbd><span class="mac-key">&hyphen;</span><kbd class="mac-key"><?php echo $keys['Option']; ?></kbd>&hyphen;<kbd><?php echo $keys['R']; ?></kbd>
							</td>
						</tr>
						<tr>
							<td><?php esc_html_e( 'Persistent search', 'cosn' ); ?></td>
							<td>
								<kbd><?php echo $keys['Alt']; ?></kbd>&hyphen;<kbd><?php echo $keys['F']; ?></kbd>
							</td>
						</tr>
					</table>
				</div>
			</div>
		</div>

		<?php
		/* Allow plugins to add fields and content to this page */
		do_action( 'cosn/admin/single', $snippet );

		/* Add a nonce for security */
		wp_nonce_field( 'cosn_save_snippet' );

		?>

		<p class="submit"><?php $this->render_submit_buttons( $snippet ); ?></p>
	</form>
</div>
