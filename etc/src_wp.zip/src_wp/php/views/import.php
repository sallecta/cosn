<?php

/**
 * HTML code for the Import Snippets page
 *
 * @package Cosn
 * @subpackage Views
 */

/* Bail if accessed directly */
if ( ! defined( 'ABSPATH' ) ) {
	return;
}

$max_size_bytes = apply_filters( 'import_upload_size_limit', wp_max_upload_size() );

?>
<div class="wrap">
	<h1><?php _e( 'Import Snippets', 'cosn' );

		$admin = cosn()->admin;

		if ( $admin->is_compact_menu() ) {

			printf( '<a href="%2$s" class="page-title-action">%1$s</a>',
				esc_html_x( 'Manage', 'snippets', 'cosn' ),
				cosn()->get_menu_url()
			);

			printf( '<a href="%2$s" class="page-title-action">%1$s</a>',
				esc_html_x( 'Add New', 'snippet', 'cosn' ),
				cosn()->get_menu_url( 'add' )
			);

			if ( isset( $admin->menus['settings'] ) ) {
				printf( '<a href="%2$s" class="page-title-action">%1$s</a>',
					esc_html_x( 'Settings', 'snippets', 'cosn' ),
					cosn()->get_menu_url( 'settings' )
				);
			}
		}

	?></h1>

	<div class="narrow">

		<p><?php _e( 'Upload one or more Cosn export files and the snippets will be imported.', 'cosn' ); ?></p>

		<p><?php
			printf(
				/* translators: %s: link to snippets admin menu */
				__( 'Afterwards, you will need to visit the <a href="%s">All Snippets</a> page to activate the imported snippets.', 'cosn' ),
				cosn()->get_menu_url( 'manage' )
			); ?></p>


		<form enctype="multipart/form-data" id="import-upload-form" method="post" class="wp-upload-form" name="cosn_import">
			<?php wp_nonce_field( 'import_cosn_file' ); ?>

			<h2><?php _e( 'Duplicate Snippets', 'cosn' ); ?></h2>

			<p class="description">
				<?php esc_html_e( 'What should happen if an existing snippet is found with an identical name to an imported snippet?', 'cosn' ); ?>
			</p>

			<fieldset>
				<p>
					<label>
						<input type="radio" name="duplicate_action" value="ignore" checked="checked">
						<?php esc_html_e( 'Ignore any duplicate snippets: import all snippets from the file regardless and leave all existing snippets unchanged.', 'cosn' ); ?>
					</label>
				</p>

				<p>
					<label>
						<input type="radio" name="duplicate_action" value="replace">
						<?php esc_html_e( 'Replace any existing snippets with a newly imported snippet of the same name.', 'cosn' ); ?>
					</label>
				</p>

				<p>
					<label>
						<input type="radio" name="duplicate_action" value="skip">
						<?php esc_html_e( 'Do not import any duplicate snippets; leave all existing snippets unchanged.', 'cosn' ); ?>
					</label>
				</p>
			</fieldset>

			<h2><?php _e( 'Upload Files', 'cosn' ); ?></h2>

			<p class="description">
				<?php _e( 'Choose one or more Cosn (.xml or .json) files to upload, then click "Upload files and import".', 'cosn' ); ?>
			</p>

			<fieldset>
				<p>
					<label for="upload"><?php esc_html_e( 'Choose files from your computer:', 'cosn' ); ?></label>
					<?php printf(
						/* translators: %s: size in bytes */
						esc_html__( '(Maximum size: %s)', 'cosn' ),
						size_format( $max_size_bytes )
					); ?>
					<input type="file" id="upload" name="cosn_import_files[]" size="25" accept="application/json,.json,text/xml" multiple="multiple">
					<input type="hidden" name="action" value="save">
					<input type="hidden" name="max_file_size" value="<?php echo esc_attr( $max_size_bytes ); ?>">
				</p>
			</fieldset>

			<?php
			do_action( 'cosn/admin/import_form' );
			submit_button( __( 'Upload files and import', 'cosn' ) );
			?>
		</form>
	</div>
</div>
